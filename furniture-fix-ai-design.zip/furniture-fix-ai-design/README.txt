FURNITURE FIX — AI STUDIO HOMEPAGE DESIGN FOR WORDPRESS

Source: user-supplied furniture-fix-manager.zip. This is a WordPress SHORTCODE PLUGIN, not a theme replacement. It does not include React admin/technician apps or claim working cloud APIs.

MOBILE INSTALL (STAGING FIRST):
1. Back up your existing WordPress site.
2. WP Admin > Plugins > Add New > Upload Plugin > select furniture-fix-ai-design.zip > Install Now > Activate.
3. On the EXISTING staging site, create a draft preview page (do not replace the current homepage).
4. Edit with Elementor, insert the Shortcode widget and paste:
   [furniture_fix_ai_home]
5. For a Forminator form that you have VERIFIED works, optionally use:
   [furniture_fix_ai_home booking_shortcode='[forminator_form id="148"]']
   Only use 148 if confirmed active. If not, leave the default and use existing Book Service page.
6. To link an alternate existing booking or tracking URL:
   [furniture_fix_ai_home booking_url="https://preview.furniturefix.services/book-service/" track_url="https://preview.furniturefix.services/track-booking/"]
7. In Elementor page settings, use Full Width or Canvas only on the preview page. If your existing theme already renders header/footer, set show_header="no" to avoid a duplicate header:
   [furniture_fix_ai_home show_header="no"]
8. Test mobile navigation, services filters, all buttons, page links, WhatsApp, review link and form.
9. Do not publish or set as live homepage until owner approves.

SECURITY/ACCURACY:
- No credentials or customer records included.
- Google 5.0 rating / 19 reviews is a dated 13 Oct 2026 verified snapshot, NOT live API sync.
- Service prices are deliberately not hardcoded because the AI Studio sample values are not the approved Excel source.
- This plugin does not generate Job IDs or save bookings; it links to existing WordPress pages and optionally embeds an already-tested booking shortcode.
- Images are copied from AI Studio ZIP and are design assets; verify commercial use permissions and authenticity before public use.
- Does not create technician/admin public access or leak private data.
- The shortcode adds its own footer and optional header. Avoid duplicates by using an Elementor Canvas preview or adjusting show_header.
